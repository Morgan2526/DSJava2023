package com.java.layer3;
import java.util.List;

import com.java.layer2.Currency;
public interface CurrencyDAO {
//	C-----------R----------U---------D
	public List<Currency> findAllCurrency();
	public Currency findCurrency(int currencyId);
	public void saveCurrency(Currency currency);
	void modifyCurrency(Currency currency);
	void removeCurrency(int currencyId);
}
