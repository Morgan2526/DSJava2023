package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.Currency;

public class CurrencyDAOImpl implements CurrencyDAO {
	Connection conn;

	public CurrencyDAOImpl() {
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());

			conn = DriverManager.getConnection("jdbc:mysql://localhost/mysql", "root", "1234");
			System.out.println(conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Currency> findAllCurrency() {
		List<Currency> curList = new ArrayList<Currency>();

		try {
			Statement statement = conn.createStatement();
			ResultSet result;
			result = statement.executeQuery("select * from currency");

			while (result.next()) {
				Currency tempCur = new Currency();
				tempCur.setCurrencyId(result.getInt(1));
				tempCur.setSourceCurrency(result.getString(2));
				tempCur.setTargetCurrency(result.getString(3));
				tempCur.setLoadFactor(result.getFloat(4));
				curList.add(tempCur);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return curList;
	}

	@Override
	public Currency findCurrency(int currencyId) {
		
		Currency curency = new Currency();
		
		
		try {
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery("Select * from currency where currencyId ="+currencyId);
			
			while(result.next())
			{
				curency.setCurrencyId(result.getInt(1));
				curency.setSourceCurrency(result.getString(2));
				curency.setTargetCurrency(result.getString(3));
				curency.setLoadFactor(result.getInt(4));
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return curency;
	}

	@Override
	public void saveCurrency(Currency currency) {
		try {
			PreparedStatement prepStatement = conn.prepareStatement("INSERT INTO CURRENCY(sourceCurrency,targetCurrency,loadFactor) VALUES(?,?,?) ");
			
			prepStatement.setString(1,currency.getSourceCurrency());
			prepStatement.setString(2,currency.getTargetCurrency());
			prepStatement.setFloat(3,currency.getLoadFactor());
			
			
			int rows = prepStatement.executeUpdate();
			
			System.out.println("executed the insert query "+rows +"  rows were added");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	@Override
	public void modifyCurrency(Currency currency) {
		try {
			PreparedStatement prepStatement;
			prepStatement = conn.prepareStatement("UPDATE Currency SET sourceCurrency=?, targetCurrency=?,loadFactor=?  WHERE currencyId = ?");
			
			prepStatement.setString(1, currency.getSourceCurrency());
			prepStatement.setString(2, currency.getTargetCurrency());
			prepStatement.setFloat(3, currency.getLoadFactor());
			prepStatement.setInt(4, currency.getCurrencyId());

			int i = prepStatement.executeUpdate();
			System.out.println("update is done! "+i );
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

	}

	@Override
	public void removeCurrency(int currencyId) {
		try {
			PreparedStatement prepStatement;
			prepStatement = conn.prepareStatement("Delete from currency where currencyId=?");

			prepStatement.setInt(1, currencyId);

			int i = prepStatement.executeUpdate();
			System.out.println("the record is deleted! "+i );
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}


