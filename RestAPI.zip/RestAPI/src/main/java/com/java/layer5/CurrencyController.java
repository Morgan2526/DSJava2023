package com.java.layer5;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.java.layer2.Currency;
import com.java.layer4.CurrencyAlreadyExisitsException;
import com.java.layer4.CurrencyNotFoundException;
import com.java.layer4.CurrencyServiceImpl;

@Path("/currency")
public class CurrencyController {
	CurrencyServiceImpl curServImp = new CurrencyServiceImpl();
	static List<Currency> curList= new ArrayList<Currency>();
	Connection conn;
	
	static {
		Currency cur1 = new Currency();
		Currency cur2 = new Currency();
		Currency cur3 = new Currency();
		Currency cur4 = new Currency();
		Currency cur5 = new Currency();
		Currency cur6 = new Currency();
		
//		cur1.setCurrencyId(1);
//		cur1.setSourceCurrency("USD");
//		cur1.setTargetCurrency("IND");
//		cur1.setAmountToConvert(500);
//		cur2.setCurrencyId(2);
//		cur2.setSourceCurrency("CND");
//		cur2.setTargetCurrency("IND");
//		cur2.setAmountToConvert(700);
//		cur3.setCurrencyId(3);
//		cur3.setSourceCurrency("CHIN");
//		cur3.setTargetCurrency("IND");
//		cur3.setAmountToConvert(900);
//		cur4.setCurrencyId(4);
//		cur4.setSourceCurrency("PAK");
//		cur4.setTargetCurrency("IND");
//		cur4.setAmountToConvert(100);
//		cur5.setCurrencyId(5);
//		cur5.setSourceCurrency("DIN");
//		cur5.setTargetCurrency("IND");
//		cur5.setAmountToConvert(200);
//		cur6.setCurrencyId(6);
//		cur6.setSourceCurrency("AUS");
//		cur6.setTargetCurrency("IND");
//		cur6.setAmountToConvert(1000);
		
		
		
		
		curList.add(cur1);
		curList.add(cur2);
		curList.add(cur3);
		curList.add(cur4);
		curList.add(cur5);
		curList.add(cur6);
	}
	
	public CurrencyController() {
		
//		try {
//			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
//			
//			conn = DriverManager.getConnection("jdbc:mysql://localhost/mysql", "root", "1234");
//			System.out.println(conn);
//			
//			Statement statement = conn.createStatement();
//			ResultSet result = statement.executeQuery("select * from currency");
//			
//			while(result.next()) {
//				Currency tempCur = new Currency();
//				tempCur.setCurrencyId(result.getInt(1));
//				tempCur.setSourceCurrency(result.getString(2));
//				tempCur.setTargetCurrency(result.getString(3));
//				tempCur.setAmountToConvert(result.getFloat(4));
//				curList.add(tempCur);
//			}
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		System.out.println("Currency service called........");
	}
	
	@GET
	@Path("/greet")
	public String welcome() {
		String ret = "<h1>WELCOME!</h1>";
		System.out.println("currency greet is called..........");
		return ret;
	}
	
	
	@GET
	@Path("/convert/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Currency convert(@PathParam("cid") int x) {
		return curServImp.findCurrencyService(x);
		
		
	}
	
	
	@GET
	@Path("/converts")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Currency> converts(){
		return curServImp.findAllCurrencyService();
	}
	
	
	@DELETE
	//@GET
	@Path("/delete/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public void delete(@PathParam("cid") int x) {
			
//		Currency curr = null;
//		boolean found = false;
//		for (Currency currency : curList) {
//			if(currency.getCurrencyId() == x)
//			{
//				curr = currency;
//				curList.remove(curr);
//				found = true;
//				break;
//				
//			}
//		}
//		
//		if(found == true) {
//			return "<h1>item deleted</h1>";
//		}
//		else {
//			return "<h1> item not found :"+x+"</h1>";
//		}
		
		curServImp.removeCurrencyService(x);
		
	}
	
	
	@POST
	@Path("/add")
	@Produces(MediaType.APPLICATION_JSON)
	public String add(Currency curr) {
		
//		boolean found =false;
//		for (Currency currency : curList) {
//			if(currency.getCurrencyId() == curr.getCurrencyId()) {
//				found = true;
//				break;
//			}
//		}
//		
//		if(found ==true) {
//			return "the object already exisits";
//		}
//		else {
//			curList.add(curr);
//			return "the currency is added";
//		

		try {
			curServImp.saveCurrencyService(curr);
			return "currency is added";
		} catch (CurrencyAlreadyExisitsException e) {
			System.out.println(e.getMessage());
			return e.getMessage();		}
		
		
	}
	
	
	@PUT
	@Path("/update")
	@Produces(MediaType.APPLICATION_JSON)
	public void modify(Currency curr) {
//		boolean found = false;
//		for (Currency currency : curList) {
//			if(currency.getCurrencyId() == curr.getCurrencyId())
//			{
//				currency.setSourceCurrency(curr.getSourceCurrency());
//				currency.setTargetCurrency(curr.getTargetCurrency());
//				currency.setAmountToConvert(curr.getAmountToConvert());
////				curList.remove(currency);
////				curList.add(curr);
//				found = true;
//			}
//		}
//		
//		if(found == true)
//		{
//			return "update done";
//		}
//		else {
//			return "no object specified found"+curr.getCurrencyId();
//		

		
		curServImp.modifyCurrencyService(curr);
				
	}
	
	
	@GET
	@Path("/convertMoney/{src}/{dst}/{amt}")
	@Produces(MediaType.APPLICATION_JSON)
	public String calculate(@PathParam("src") String src,@PathParam("dst") String dst, @PathParam("amt") float amt) 
	{
		float returnAmt = 0;
		try {
			returnAmt =curServImp.calculateExchangeRate(src, dst, amt);
		} catch (CurrencyNotFoundException e) {
			return e.getMessage();
		}
		return ""+returnAmt;
	}

}
