package com.java.layer4;

public class SourceCurrencyNotFoundException extends CurrencyNotFoundException {

	public SourceCurrencyNotFoundException(String err) {
		super(err);
	}

	

}
