package com.java.layer4;

import java.util.List;

import com.java.layer2.Currency;

public interface CurrencyService {

	public List<Currency> findAllCurrencyService();
	public Currency findCurrencyService(int currencyId);
	public void saveCurrencyService(Currency currency) throws CurrencyAlreadyExisitsException;
	void modifyCurrencyService(Currency currency);
	void removeCurrencyService(int currencyId);

}
