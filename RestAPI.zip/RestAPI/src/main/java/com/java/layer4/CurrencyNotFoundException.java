package com.java.layer4;

public class CurrencyNotFoundException extends Exception {

	public CurrencyNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	 
	
}
