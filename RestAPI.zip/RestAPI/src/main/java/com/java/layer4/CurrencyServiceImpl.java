package com.java.layer4;

import java.util.Iterator;
import java.util.List;

import com.java.layer2.Currency;
import com.java.layer3.CurrencyDAOImpl;

public class CurrencyServiceImpl implements CurrencyService {
		
	CurrencyDAOImpl currencyDAO = new CurrencyDAOImpl();
	
	@Override
	public List<Currency> findAllCurrencyService() {
		return currencyDAO.findAllCurrency();
	}

	@Override
	public Currency findCurrencyService(int currencyId) {
		return currencyDAO.findCurrency(currencyId) ;
	}

	@Override
	public void saveCurrencyService(Currency currency) throws CurrencyAlreadyExisitsException {
		Boolean sourceFound = false;
		Boolean targetFound = false;
		List<Currency> currList = currencyDAO.findAllCurrency();
		
		Iterator<Currency> currIterator = currList.iterator();
		while(currIterator.hasNext()) {
			Currency tempCur =currIterator.next();
			if(tempCur.getSourceCurrency().equalsIgnoreCase(currency.getSourceCurrency()) ) {
				sourceFound=true;
				if(tempCur.getTargetCurrency().equalsIgnoreCase(currency.getTargetCurrency())) {
				targetFound = true;
			}
			
		}
	}
		
		if(sourceFound == true && targetFound == true) {
			throw new CurrencyAlreadyExisitsException("this currency already exisits");
		}
		else {

		currencyDAO.saveCurrency(currency);
		// TODO Auto-generated method stub
		}
	}

	@Override
	public void modifyCurrencyService(Currency currency) {
		// TODO Auto-generated method stub
		currencyDAO.modifyCurrency(currency);
		
	}

	@Override
	public void removeCurrencyService(int currencyId) {
		// TODO Auto-generated method stub
		currencyDAO.removeCurrency(currencyId);
	}

	
	public float calculateExchangeRate(String source,String target,float amountToConvert) throws CurrencyNotFoundException {
		float calculatedamt=0;
		Boolean sourceFound = false;
		Boolean targetFound = false;
		List<Currency> currList = currencyDAO.findAllCurrency();
		
		Iterator<Currency> currIterator = currList.iterator();
		while(currIterator.hasNext()) {
			Currency tempCur =currIterator.next();
			if(tempCur.getSourceCurrency().equalsIgnoreCase(source) ) {
				sourceFound=true;
				if(tempCur.getTargetCurrency().equalsIgnoreCase(target)) {
				float gotLoadFactor = tempCur.getLoadFactor();
				targetFound = true;
				calculatedamt = gotLoadFactor* amountToConvert;
			}
			
		}
	}
		
		if(sourceFound == false) {
			 CurrencyNotFoundException exception = new SourceCurrencyNotFoundException("the requested source currency is not found");
			throw exception;
		}
		if(targetFound == false) {
			
			CurrencyNotFoundException exception1 =new TargetCurrencyNotFoundException("the requested target currency is not found!");
			
			throw exception1;
			
			
		}
		
		return calculatedamt;
	}
	

}
