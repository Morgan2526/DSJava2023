package com.java.layer4;

public class TargetCurrencyNotFoundException extends CurrencyNotFoundException {

	public TargetCurrencyNotFoundException(String message) {
		super(message);
		
	}
	
}
