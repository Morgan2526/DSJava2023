package com.java.layer4;

public class CurrencyAlreadyExisitsException extends Exception {

	public CurrencyAlreadyExisitsException(String message) {
		super(message);
	}

}
