package com.java.layer3;

import org.junit.Test;

import com.java.layer2.Currency;
import com.java.layer4.CurrencyAlreadyExisitsException;
import com.java.layer4.CurrencyServiceImpl;

public class DAOServiceTest {
	
	CurrencyServiceImpl curServImpl = new CurrencyServiceImpl();
	
	
	@Test
	public void addCurrencyTest() {
		
		Currency curr = new Currency();
		curr.setLoadFactor(120);
		curr.setSourceCurrency("ABC");
		curr.setTargetCurrency("XYZ");
		
		try {
			curServImpl.saveCurrencyService(curr);
		} catch (CurrencyAlreadyExisitsException e) {
				System.out.println("Error "+e);
		}
	}
	
}
