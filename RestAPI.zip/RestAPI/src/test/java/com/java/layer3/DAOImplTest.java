package com.java.layer3;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.java.layer2.Currency;
import com.java.layer4.CurrencyServiceImpl;
import com.java.layer4.SourceCurrencyNotFoundException;

public class DAOImplTest {

	@Test
	public void testAllCurrencies() {
		System.out.println("starting to test DAO");
		
		CurrencyDAO currDAO = new CurrencyDAOImpl();
		
		Assert.assertTrue(currDAO != null);
		
		List<Currency> currList = currDAO.findAllCurrency();
		Assert.assertTrue(currList.size() > 0);
		
		for (Currency currency : currList) {
			System.out.println(currency);
		}
	}
	
	
	@Test
	public void testLoadSingleCurrency() {
		System.out.println("starting to test single currency DAO");
		
		CurrencyDAO currDAO = new CurrencyDAOImpl();
		
		Assert.assertTrue(currDAO != null);
		
		Currency cur = currDAO.findCurrency(14);
		Assert.assertTrue(cur!=null);
		System.out.println(cur);
	}
	
	@Test
	public void testAddCurrency() {
		System.out.println("started to test add currency");
		
		CurrencyDAO currDAO = new CurrencyDAOImpl();
		Assert.assertTrue(currDAO != null);
		
		Currency curr = new Currency();
		Assert.assertTrue(curr!=null);
		
		curr.setLoadFactor(100);
		curr.setSourceCurrency("BAN");
		curr.setTargetCurrency("SRI");
		
		
		System.out.println("Currency " +curr);
		currDAO.saveCurrency(curr);
		System.out.println("Currency is added....");
		
	}
	
	
	@Test
	public void testUpdateCurrency() {
System.out.println("started to test Updated currency");
		
		CurrencyDAO currDAO = new CurrencyDAOImpl();
		Assert.assertTrue(currDAO != null);
		
		Currency curr = new Currency();
		Assert.assertTrue(curr!=null);
		
		curr.setLoadFactor(100);
		curr.setCurrencyId(7);
		curr.setSourceCurrency("NIG");
		curr.setTargetCurrency("IND");
		
		
		System.out.println("Currency " +curr);
		currDAO.saveCurrency(curr);
		System.out.println("Currency is Updated....");
	}
	
	
	@Test
	public void testCalculate() {
System.out.println("started to test Updated currency");
		
		CurrencyServiceImpl curServImp = new CurrencyServiceImpl();
		
		float calc=0;
		try {
			calc = curServImp.calculateExchangeRate("IND", "AUS", 1000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("converted value is "+calc);
	}
	
	
	
	@Test
	public void removeCurrency() {
		CurrencyServiceImpl curServImp = new CurrencyServiceImpl();
		curServImp.removeCurrencyService(13);
	}

}
