package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ds.pojo.Employee;


@WebServlet("/emp")
public class EmployeeManagementServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      ArrayList<Employee> empList = new ArrayList<Employee>();

    public EmployeeManagementServelet() {
        super();

    }


	public void init(ServletConfig config) throws ServletException {
		System.out.println("init() is invokede............");
		
		Employee emp1 = new Employee(101,"Prem Gumathanavar","CEO",1000000);
		Employee emp2 = new Employee(102,"Ridham Sawhney","CEO",1000000);
		Employee emp3 = new Employee(103,"Allauddin Jamkhanewale","CEO",1000000);
		Employee emp4 = new Employee(104,"Shreyes Bambhore","Receptionist",1000000);
		Employee emp5 = new Employee(105,"Mahadev Rashinkar","Analyst",1000000);
		Employee emp6 = new Employee(106,"Param Jangle","CEO",1000000);
		Employee emp7 = new Employee(107,"Nitish Supe","CEO",1000000);
		Employee emp8 = new Employee(108,"Suvomoy Maitra","CEO",1000000);
		
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		empList.add(emp4);
		empList.add(emp5);
		empList.add(emp6);
		empList.add(emp7);
		empList.add(emp8);

	}


	public void destroy() {
		System.out.println("destroy() is invokede............");
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doget(req,res) is invoked............");
		HttpSession session = request.getSession(true);
		session.setAttribute("allEmp", empList);
		PrintWriter pw = response.getWriter();
		
		pw.println("<h1 style='text-align:center' >All Employees</h1>");
		pw.println("<table border = 2 cellspacing = 5  width = 50%>");
		pw.println("<tr>");
		pw.println("<th> Emp No</th>");
		pw.println("<th> Emp Name</th>");
		pw.println("<th> Employee Role</th>");
		pw.println("<th> Employee salary </th>");
		pw.println("<form action='addEmployee'>");
		pw.println("<tr>");
		pw.println("<td>");
		pw.println("<input type='number' name='empno' placeholder='EMP NO'>" );
		pw.println("</td>");
		pw.println("<td>");
		pw.println("<input type='text' name='empname' placeholder='EMP Name'>" );
		pw.println("</td>");
		pw.println("<td>");
		pw.println("<input type='text' name='empjob' placeholder='EMP Job'>" );
		pw.println("</td>");
		pw.println("<td>");
		pw.println("<input type='number' name='empsal' placeholder='EMP Sal'>" );
		pw.println("</td>");
		pw.println("<td>");
		pw.println("<input type='submit' value='add'>");
		pw.println("</td>");
		pw.println("</tr>");
		pw.println("</form>");
			Iterator<Employee> empIterator = empList.iterator();
			
			while(empIterator.hasNext())
			{
				Employee tempEmp = empIterator.next();
				
				
				
				
				
				
				
				pw.println("<form action='updateEmployee'>");
				pw.println("<tr>");
				pw.println("<td>");
					pw.println(tempEmp.getEmployeeId());
					pw.println("<input type=hidden name='empno' value='"+tempEmp.getEmployeeId()+"'>");
				pw.println("</td>");
				pw.println("<td>");
					pw.println("<input type=text name='empname' value='"+tempEmp.getEmployeeName()+"'>");
				pw.println("</td>");
				pw.println("<td>");
					pw.println("<input type=text name='empjob' value='"+tempEmp.getEmployeeRole()+"'>");
				pw.println("</td>");
				pw.println("<td>");
					pw.println("<input type=text name='empsal' value='"+tempEmp.getEmployeeSalary()+"'>");
				pw.println("</td>");	
				pw.println("<td>");
					pw.println("<input type=submit name=submit value='Edit'>");
				pw.println("</td>");
			
				pw.println("</form>");

				
				
				
				
				
				
		//		pw.println("<tr>");
		//		pw.println("<td>");
		//		pw.println(tempEmp.getEmployeeId());
		//		pw.println("</td>");
		//		pw.println("<td>");
		//		pw.println(tempEmp.getEmployeeName());
		//		pw.println("</td>");
		//		pw.println("<td>");
		//		pw.println(tempEmp.getEmployeeRole());
		//		pw.println("</td>");
		//		pw.println("<td>");
		//		pw.println(tempEmp.getEmployeeSalary());
		//		pw.println("</td>");
				
				pw.println("<td>");
				pw.println("<form action='deleteEmp'>");
				pw.println("<input type = hidden  name = 'empno' value ='"+tempEmp.getEmployeeId()+"'>");
				pw.println("<input type='submit'  value='delete'>");
				pw.println("</form>");
				pw.println("</td>");
				
			}
			
		pw.println("</table>");
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost(req,res) is invoked............");
		doGet(request, response);
		

	}

}
